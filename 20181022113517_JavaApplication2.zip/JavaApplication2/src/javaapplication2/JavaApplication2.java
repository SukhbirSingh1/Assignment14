/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author 1794054
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner Keyboard = new Scanner(System.in);
        Random randomObj = new Random();

        int elementCount = 0;
        int i;
        int j;
     //  int position=0;

        System.out.println("How many elements ");
        elementCount = Keyboard.nextInt();

        int[] array = new int[elementCount];

        System.out.println("Random numbers are :");
        for (i = 0; i < elementCount; i++) {
            // array1[i]=randomObj.nextInt(1000);
            //  array1[i] = randomObj.nextInt(1000);
            System.out.print((i + 1) + ":");
            // array1[i]=Keyboard.nextInt();
            array[i] = randomObj.nextInt(1000);
            System.out.println(array[i]);
        }
        int Search;

        System.out.print("Which number to search?");
        Search = Keyboard.nextInt();
        System.out.println("   ");
        for (i = 0; i < elementCount; i++) {
            if (Search == array[i]) {
          // position=i+1;
                // }}
                // if(position==0){
                System.out.println("Element found at index " + "  " + i + 1);
            } else {
                // System.out.println("location not found");
            }
        }
        System.out.println("  ");
        System.out.println("End of this assignment");

    }
}
